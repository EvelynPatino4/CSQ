#include "graph.h"
#include <iostream>
#include <queue>
#include <stack>
#include <iomanip>
#include <cstring>

using namespace std;

Graph::Graph(int maxV)
{
    maxVertices = maxV;
    numVertices = 0;
    vertices = nullptr;

    adjMatrix = new int*[maxVertices]; // pointer of rows
     // each int* stores a row
    for (int i = 0; i < maxVertices; i++)
    {
        adjMatrix[i] = new int[maxVertices]; // create a new row (array of ints)
        for (int j = 0; j < maxVertices; j++)
            adjMatrix[i][j] = 0;
    }

    visited = new bool[maxVertices]{false};
}

Graph::~Graph()
{
    delete[] visited;

    for (int i = 0; i < maxVertices; i++)
    {
        delete[] adjMatrix[i];
    }
    delete[] adjMatrix;

    vertex* tempVertex;
    while (vertices)
    {
        edge* tempEdge;
         // free the memory of the neighbor list of that vertex
        while (vertices->aHead)
        {
            tempEdge = vertices->aHead;
            vertices->aHead = vertices->aHead->eNext;
            delete tempEdge;
        }
        // free that vertex itself
        tempVertex = vertices;
        vertices = vertices->vNext;
        delete tempVertex;
    }
}

void Graph::addVertex(char data)
{
    if (numVertices >= maxVertices)
    {
        cout << "Max number of vertices reached!" << endl;
        return;
    }

    vertex* newVertex = new vertex;
    newVertex->data = data;
    newVertex->vNext = vertices;
    newVertex->aHead = nullptr;
    newVertex->visited = 0;
    vertices = newVertex;

    numVertices++;
}

void Graph::addEdge(char src, char dest, int weight)
{
    vertex* srcVertex = vertices;
    vertex* destVertex = vertices;

    // find src and dest vertices
    while (srcVertex && srcVertex->data != src)
        srcVertex = srcVertex->vNext;
    while (destVertex && destVertex->data != dest)
        destVertex = destVertex->vNext;

    if (!srcVertex || !destVertex)
    {
        cout << "Vertices not found - can't add an edge" << endl;
        return;
    }

    // Adj list - undirected graph
    edge* newEdge = new edge;
    newEdge->dest = destVertex;
    newEdge->weight = weight;
    newEdge->eNext = srcVertex->aHead;
    srcVertex->aHead = newEdge;

    // Since undirected, add the reverse edge as well
    newEdge = new edge;
    newEdge->dest = srcVertex;
    newEdge->weight = weight;
    newEdge->eNext = destVertex->aHead;
    destVertex->aHead = newEdge;

    // Adj Matrix
    int srcIndex = srcVertex->data - 'A';
    int destIndex = destVertex->data - 'A';
    adjMatrix[srcIndex][destIndex] = weight;
    adjMatrix[destIndex][srcIndex] = weight;
}

void Graph::removeEdge(char src, char dest)
{
    int srcIndex = src - 'A';
    int destIndex = dest - 'A';

    adjMatrix[srcIndex][destIndex] = 0;
    adjMatrix[destIndex][srcIndex] = 0;

    vertex* srcVertex = vertices;
    while (srcVertex && srcVertex->data != src) srcVertex = srcVertex->vNext;
    edge** e = &srcVertex->aHead;
    while (*e)
    {
        if ((*e)->dest->data == dest)
        {
            edge* temp = *e;
            *e = (*e)->eNext;
            delete temp;
            break;
        }
        e = &(*e)->eNext;
    }
    //removeEdgeFromVertex
    vertex* destVertex = vertices;
    while (destVertex && destVertex->data != dest) destVertex = destVertex->vNext;
    e = &destVertex->aHead;
    while (*e)
    {
        if ((*e)->dest->data == src)
        {
            edge* temp = *e;
            *e = (*e)->eNext;
            delete temp;
            break;
        }
        e = &(*e)->eNext;
    }
}

void Graph::bfsM(char start)
{
    for (int i = 0; i < maxVertices; i++)
        visited[i] = false;

    int startIndex = start - 'A';
    queue<int> q;
    q.push(startIndex);
    visited[startIndex] = true;

    cout << "BFS (Matrix) from " << start << ": ";
    while (!q.empty())
    {
        int current = q.front();
        q.pop();
        cout << char('A' + current) << " ";

        for (int i = 0; i < maxVertices; i++)
        {
            if (adjMatrix[current][i] != 0 && !visited[i])
            {
                visited[i] = true;
                q.push(i);
            }
        }
    }
    cout << endl;
}

void Graph::dfsL(char start)
{
    for (int i = 0; i < maxVertices; i++)
        visited[i] = false;

    stack<int> s;
    int startIndex = start - 'A';
    s.push(startIndex);
    visited[startIndex] = true;

    cout << "DFS (List) from " << start << ": ";
    while (!s.empty())
    {
        int current = s.top();
        s.pop();
        cout << char('A' + current) << " ";

        vertex* currentVertex = vertices;
        while (currentVertex && currentVertex->data != char('A' + current))
            currentVertex = currentVertex->vNext;

        for (edge* e = currentVertex->aHead; e != nullptr; e = e->eNext)
        {
            int neighborIndex = e->dest->data - 'A';
            if (!visited[neighborIndex])
            {
                visited[neighborIndex] = true;
                s.push(neighborIndex);
            }
        }
    }
    cout << endl;
}

void Graph::dfsM(char start)
{
    for (int i = 0; i < maxVertices; i++)
        visited[i] = false;

    stack<int> s;
    int startIndex = start - 'A';
    s.push(startIndex);
    visited[startIndex] = true;

    cout << "DFS (Matrix) from " << start << ": ";
    while (!s.empty())
    {
        int current = s.top();
        s.pop();
        cout << char('A' + current) << " ";

        for (int i = 0; i < maxVertices; i++)
        {
            if (adjMatrix[current][i] != 0 && !visited[i])
            {
                visited[i] = true;
                s.push(i);
            }
        }
    }
    cout << endl;
}

bool Graph::detectCycleUtil(int v, bool visited[], bool recStack[])
{
    if (recStack[v]) return true;
    if (visited[v]) return false;

    visited[v] = true;
    recStack[v] = true;

    vertex* currentVertex = vertices;
    while (currentVertex && currentVertex->data != char('A' + v))
        currentVertex = currentVertex->vNext;

    for (edge* e = currentVertex->aHead; e != nullptr; e = e->eNext)
    {
        int neighborIndex = e->dest->data - 'A';
        if (detectCycleUtil(neighborIndex, visited, recStack))
            return true;
    }

    recStack[v] = false;
    return false;
}

bool Graph::detectCycle()
{
    bool* visited = new bool[maxVertices]{false};
    bool* recStack = new bool[maxVertices]{false};

    for (int i = 0; i < maxVertices; i++)
    {
        if (!visited[i] && detectCycleUtil(i, visited, recStack))
        {
            delete[] visited;
            delete[] recStack;
            return true;
        }
    }

    delete[] visited;
    delete[] recStack;
    return false;
}


