#ifndef GRAPH_H
#define GRAPH_H

#include <iostream>
#include <iomanip>
#include <queue>
#include <stack>


using namespace std;

struct edge
{
    struct vertex* dest;
    edge* eNext;
    int weight;
};

struct vertex
{
    char data;
    vertex* vNext;
    edge* aHead;
    bool visited;
};

// implementing both adj list and adj matrix for an undirected weighed graph
class Graph 
{
    private:
        vertex* vertices; // list of vertices
        int** adjMatrix; 
        bool* visited;
        int maxVertices;
        int numVertices;

    public:
        Graph(int maxV);
        ~Graph();

        // core operations
        void addVertex(char data);
        void addEdge(char src, char dest, int weight);
        void removeVertex(char data);
        void removeEdge(char src, char dest);  // complete this

        // display
        void displayAdjList();
        void displayAdjMatrix();

        // traversal/search algorithms
        void bfsL(char start);
        void bfsM(char start); // complete this
        void dfsL(char start);
        void dfsM(char start);   

        bool detectCycle();  // Detect cycle in the graph

        // ---------------- Extra Credits - Pick one of the two ----------------------------- 
        // Detect cycle with DFS - Option 1
        // bool detectCycleDFS();

        // Print Connected Components - Option 2
        // void connectedComponents();

        private:
        // Helper functions for cycle detection (used by detectCycle)
        bool detectCycleUtil(int v, bool visited[], bool recStack[]);
};

#endif
