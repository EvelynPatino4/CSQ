About: A6 - Part_1 CSC 300
Date: Apr 19, 2025
Comments: Includes four files -> graph.cpp, graph.h, mainGraph.cpp, sqll.cpp, sqll.h, README.txt

*** FIRST OPEN THE FOLDER WHERE THESE THREE FILES ARE LOCATED:
    In command prompt: /Users/evelynpatino/Documents/graph-2
		   
*** 

graph.cpp folder
To compile: g++ mainGraph.cpp graph.cpp -o graph_program
To run: ./graph_program

