#include <iostream>
#include <cstdlib>
#include <ctime>
#include "game.h"

using namespace std;

int main() {
    play();
    return 0;
}


