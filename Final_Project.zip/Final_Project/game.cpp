#include <iostream>
#include <cstdlib>
#include <ctime>
#include "game.h"

using namespace std;

// Array implementation
Array::Array(int s) {
    size = s;
    arr = new int[size](); // initialize with 0s
}
Array::~Array() {
    delete[] arr;
}
void Array::set(int index, int value) {
    if (index >= 0 && index < size) {
        arr[index] = value;
    }
}
int Array::get(int index) {
    if (index >= 0 && index < size) {
        return arr[index];
    }
    return -1;
}

// Stack implementation
Stack::Stack(int cap) {
    capacity = cap;
    stackArray = new int[capacity];
    top = -1;
}
Stack::~Stack() {
    delete[] stackArray;
}
void Stack::push(int value) {
    if (top < capacity - 1) {
        stackArray[++top] = value;
    }
}
int Stack::pop() {
    if (top >= 0) {
        return stackArray[top--];
    }
    return -1;
}
bool Stack::isEmpty() {
    return top == -1;
}

// Queue implementation
Queue::Queue(int cap) {
    capacity = cap;
    queueArray = new int[capacity];
    front = 0;
    rear = -1;
}
Queue::~Queue() {
    delete[] queueArray;
}
void Queue::enqueue(int value) {
    if (rear < capacity - 1) {
        queueArray[++rear] = value;
    }
}
int Queue::dequeue() {
    if (front <= rear) {
        return queueArray[front++];
    }
    return -1;
}
bool Queue::isEmpty() {
    return front > rear;
}

// Linked list functions
void insert(Node*& head, int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = head;
    head = newNode;
}
void printList(Node* head) {
    Node* current = head;
    cout << "\nGuesses made (linked list): ";
    while (current != nullptr) {
        cout << current->data << " ";
        current = current->next;
    }
    cout << endl;
}

// Generate random number
int getSecretNumber() {
    return (rand() % 100) + 1;
}

// Validate integer input (unused)
bool getValidInput(int& guess) {
    string input;
    cin >> input;

    for (char c : input) {
        if (!isdigit(c)) return false;
    }

    guess = stoi(input);
    return true;
}

// Game logic
void play() {
    srand(time(0));
    int secret = getSecretNumber();
    Array guessed(101);
    Stack guessStack(101);
    Queue guessQueue(101);
    Node* guessList = nullptr;

    string input;
    int guess;
    bool isPlaying = true;

    // Prime check lambda
    auto isPrime = [](int num) -> bool {
        if (num < 2) return false;
        for (int i = 2; i * i <= num; ++i) {
            if (num % i == 0) return false;
        }
        return true;
    };

    // Initial hints
    cout << "🎯 Starting Hints:\n";
    cout << (secret % 2 == 0 ? "👉 Hint: The secret number is even.\n" : "👉 Hint: The secret number is odd.\n");
    cout << (!isPrime(secret) ? "👉 Hint: The secret number is not a prime number.\n" : "👉 Hint: The secret number is a prime number.\n");

    cout << "\nGuess a number between 1 and 100.\nType 'u' to undo your last guess or 'q' to quit.\n";

    while (isPlaying) {
        cout << "\nYour guess: ";
        cin >> input;

        if (input == "q") {
            cout << "👋 You quit. The secret number was: " << secret << "\n";
            break;
        } else if (input == "u") {
            if (!guessStack.isEmpty()) {
                int last = guessStack.pop();
                guessed.set(last, 0);
                cout << "⏪ Undid guess: " << last << "\n";
            } else {
                cout << "⚠️ Nothing to undo!\n";
            }
            continue;
        }

        try {
            guess = stoi(input);
        } catch (...) {
            cout << "❌ Invalid input. Please enter a number.\n";
            continue;
        }

        if (guess < 1 || guess > 100) {
            cout << "⚠️ Number out of range. Try between 1 and 100.\n";
            continue;
        }

        if (guessed.get(guess) > 0) {
            cout << "🔁 You've already guessed " << guess << ". Try a different number.\n";
            continue;
        }

        guessed.set(guess, 1);
        guessStack.push(guess);
        guessQueue.enqueue(guess);
        insert(guessList, guess);

        if (guess == secret) {
            cout << "\n🎊👏 You did it! That's the number! 🎯 " << secret << "!\n";
            isPlaying = false;
        } else {
            int distance = abs(secret - guess);
            cout << (guess < secret ? "📉 Your guess is too low.\n" : "📈 Your guess is too high.\n");
            cout << "📌 Hint: You are " << distance << " away from the secret number.\n";
            cout << (secret % 2 == 0 ? "👉 Reminder: The secret number is even.\n" : "👉 Reminder: The secret number is odd.\n");
            cout << (!isPrime(secret) ? "👉 Reminder: It is NOT a prime number.\n" : "👉 Reminder: It IS a prime number.\n");
        }
    }

    // Display guess history
    cout << "\n📋 Guesses made (queue): ";
    while (!guessQueue.isEmpty()) {
        cout << guessQueue.dequeue() << " ";
    }

    printList(guessList);
}

