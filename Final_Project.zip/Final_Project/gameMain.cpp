#include <iostream>
using namespace std;

class Queue {
private:
    int* queueArray;
    int front;
    int rear;
    int capacity;

public:
    Queue(int size) {
        queueArray = new int[size];
        front = -1;
        rear = -1;
        capacity = size;
    }

    ~Queue() {
        delete[] queueArray;
    }

    bool isEmpty() {
        return (front == -1);
    }

    bool isFull() {
        return (rear == capacity - 1);
    }

    void enqueue(int value) {
        if (isFull()) {
            cout << "Queue is full!" << endl;
            return;
        }
        if (front == -1) {
            front = 0;
        }
        queueArray[++rear] = value;
    }

    void dequeue() {
        if (isEmpty()) {
            cout << "Queue is empty!" << endl;
            return;
        }
        front++;
        if (front > rear) {
            front = rear = -1;
        }
    }

    int peek() {
        if (isEmpty()) {
            cout << "Queue is empty!" << endl;
            return -1;
        }
        return queueArray[front];
    }
};




