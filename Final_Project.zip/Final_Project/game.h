#ifndef GAME_H
#define GAME_H

// Node structure for linked list
struct Node {
    int data;
    Node* next;
};

// Class representing a custom dynamic array
class Array {
public:
    Array(int size);        // Constructor
    ~Array();               // Destructor
    void set(int index, int value);  // Set value at index
    int get(int index);             // Get value at index

private:
    int* arr;   // Pointer to the array
    int size;   // Size of the array
};

// Class representing a stack
class Stack {
public:
    Stack(int cap);         // Constructor
    ~Stack();               // Destructor
    void push(int value);   // Push value onto the stack
    int pop();              // Pop value from the stack
    bool isEmpty();         // Check if the stack is empty

private:
    int* stackArray;
    int top;
    int capacity;
};

// Class representing a queue
class Queue {
public:
    Queue(int cap);         // Constructor
    ~Queue();               // Destructor
    void enqueue(int value);    // Enqueue value to the queue
    int dequeue();          // Dequeue value from the queue
    bool isEmpty();         // Check if the queue is empty

private:
    int* queueArray;
    int front;
    int rear;
    int capacity;
};

// Function declarations
void insert(Node*& head, int value);
void printList(Node* head);
int getSecretNumber();
bool getValidInput(int& guess);
void play();

#endif // GAME_H
